import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  // WebSocket للتواصل مع rosbridge
  late final WebSocketChannel ch;
  // مؤقت لارسال اوامر بشكل دوري عند الضغط مطول
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    ch = WebSocketChannel.connect(Uri.parse('ws://192.168.222.129:9090'));

    // /turtle1/cmd_vel 
    ch.sink.add(jsonEncode({
      "op": "advertise",
      "topic": "/turtle1/cmd_vel",
      "type": "geometry_msgs/msg/Twist"
    }));
  }

  void _publish(double v, double w) {
    ch.sink.add(jsonEncode({
      "op": "publish",
      "topic": "/turtle1/cmd_vel",
      "msg": {
      "linear": {"x": v, "y": 0.0, "z": 0.0},
      "angular": {"x": 0.0, "y": 0.0, "z": w}
      }
    }));
  }

  void _start(double v, double w) {
    _timer?.cancel();
    _timer = Timer.periodic(
      const Duration(milliseconds: 100),
      (_) => _publish(v, w),
    );
  }

  // توقف فوري
  void _stop() {
    _timer?.cancel();
    _publish(0, 0); // إرسال أمر توقف
  }

  @override
  void dispose() {
    _timer?.cancel();
    ch.sink.add(jsonEncode({"op": "unadvertise", "topic": "/turtle1/cmd_vel"}));
    ch.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // قيم افتراضي لسرعات 
    const v = 2.0; // السرعة الخطية
    const w = 2.5; // السرعة الزاوية

    // نمط زر ازرق موحد
    final blueBtn = ElevatedButton.styleFrom(backgroundColor: Colors.blue);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
      appBar: AppBar(
      title: const Text(
      'TurtleSimController',
      style: TextStyle(decoration: TextDecoration.underline),
      ),
      ),
      body: Center(
      child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
      // زر ↑ للأمام:
      //  الضغط السريع يرسل نبضة واحدة
      // الضغط المطول يبدا ارسال حتى الإفلات
      GestureDetector(
    onLongPressStart: (_) => _start(v, 0),
    onLongPressEnd: (_) => _stop(),
    child: ElevatedButton(
    style: blueBtn,
    onPressed: () => _publish(v, 0),
    child: const Icon(Icons.arrow_upward),
    ),
    ),
 // الصف الاوسط: يسار / أسفل / يمين
    Row(
    mainAxisSize: MainAxisSize.min,
    children: [
    // ← دوران لليسار
    GestureDetector(
    onLongPressStart: (_) => _start(0, w),
    onLongPressEnd: (_) => _stop(),
    child: ElevatedButton(
    style: blueBtn,
    onPressed: () => _publish(0, w),
    child: const Icon(Icons.arrow_back),
    ),
    ),
    const SizedBox(width: 12),
// ↓ رجوع للخلف
    GestureDetector(
    onLongPressStart: (_) => _start(-v, 0),
    onLongPressEnd: (_) => _stop(),
    child: ElevatedButton(
    style: blueBtn,
    onPressed: () => _publish(-v, 0),
    child: const Icon(Icons.arrow_downward),
    ),
    ),
    const SizedBox(width: 12),
// → دوران لليمين
    GestureDetector(
    onLongPressStart: (_) => _start(0, -w),
    onLongPressEnd: (_) => _stop(),
    child: ElevatedButton(
    style: blueBtn,
    onPressed: () => _publish(0, -w),
    child: const Icon(Icons.arrow_forward),
    ),
    ),
    ],
    ),
    const SizedBox(height: 12),
 // زر ايقاف واضح لإرسال (0,0) وايقاف المؤقت
    ElevatedButton(
    style: blueBtn,
    onPressed: _stop,
    child: const Text('Stop'),
    ),
    ],
    ),
    ),
    ),
    );
  }
}